/*  Identifier = 15C1680EE94C640EC35E1694295A3625C3254CBA

    EECS 281 Lab 4: Connected Components

    For this lab, you will write a program that calculates the
    number of connected components in an undirected graph.

    Your program will receive an input file in the following format:
    1) The first line of input contains the number of vertices V and number
       of edges E in the graph.
    2) The next E lines list out the connections between vertices in the
       graph in the format of "u v", which indicates the existence of an edge
       between u and v.

    For example, the following input file would be read as follows:
    4 2  (the graph has 4 vertices numbered from 0-3, and two edges exist in
          the graph)
    0 1  (the first of these edges connects vertex 0 with vertex 1)
    0 2  (the second of these edges connects vertex 0 with vertex 2)

    In this case, vertices {0, 1, 2} form a connected component, and vertex
    {3} forms a connected component (since 3 is not connected to anything).
    Thus, your program should print out 2.

    You will be using union-find to complete this lab. The following starter
    code has been provided. Feel free to modify this code in your
    implementation. Good luck!
*/

#include <iostream>
using std::cin;
using std::cout;
using std::endl;
#include <vector>
#include <cstdint>
using std::vector;

class Graph {
    uint32_t V;
    uint32_t E;
    // TODO: add any additional member variables, as needed
    vector<uint32_t> reps;
    vector<uint32_t> rank;

public:
    // Graph constructor that initializes the graph and its member variables
    Graph(uint32_t v, uint32_t e) : V{v}, E{e}, reps(v), rank(v, 1) {
        // TODO: initialize member variables that you added above
        // for each 
        for (uint32_t i = 0; i < v; ++i) {
            reps[i] = i;
        }
    }  // Graph()


    uint32_t find_set(uint32_t v) {
        // TODO: implement the find_set function
        //for each v while the representative is
        //not the same vertex set rep of v to the 
        //final vertex where the path closes (i.e.
        //the rep vertex is equal to the current
        //vertex) by calling find_set repeatedly
        //until the if statement is false. Then return
        //the last reps[v] as that is the compressed
        //path
        if (reps[v] != v) {
            reps[v] = find_set(reps[v]);  
        }
        return reps[v];
    }  // find_set()


    void union_set(uint32_t a, uint32_t b) {
        // TODO: implement the union_set function
        //find the path compressed roots for the
        //two vertices entered
        uint32_t a_root = find_set(a);
        uint32_t b_root = find_set(b);

        //if the roots are not equal 
        //then check if one root can be 
        //joined to the other by comparing 
        //the ranks of the roots or how 
        //many times that root occurs
        if (a_root != b_root) {
            //if the rank of a is larger then set
            //root of b to a
            if (rank[a_root] > rank[b_root]) {
                reps[b_root] = a_root;
            } 
            //if the rank if b is larger the set
            //root of a to b
            else if (rank[a_root] < rank[b_root]) {
                reps[a_root] = b_root;
            } 
            //if the ranks are equal (as they are
            //at the beginning) set the first vertex
            //entered as the higher rank and set the
            //root of b to a
            else {
                reps[b_root] = a_root;
                rank[a_root]++;
            }
        }
    }  // union_set()


    uint32_t count_components() {
        // TODO: implement the count_components function
        // count variable
        uint32_t count = 0;
        //std::ifstream myfile;
        //myfile.open("test_case1.in");
        //for loop through all edges 
        //create two variables for the
        //two vertices for each edge
        uint32_t v1;
        uint32_t v2;
        for (uint32_t i = 0; i < E; ++i) {
            //read in every line
            cin >> v1 >> v2;
            //cout << v1 << "," << v2 << endl;
            //call union set for each edge
            union_set(v1, v2);
        }

        //for all the vertices count how many times
        //the graph closes (find returns the same
        //end vertex as the start)
        for (uint32_t v = 0; v < V; ++v) {
            if (find_set(v) == v) {
                count++;
            }
        }
        //myfile.close();
        return count;
    }  // count_components()
};  // Graph{}


int main() {
    // You do not need to modify main.
    std::ios_base::sync_with_stdio(false);
    uint32_t vertex_count, edge_count = 0;

    cin >> vertex_count;
    cin >> edge_count;

    Graph g(vertex_count, edge_count);

    cout << g.count_components() << endl;
    return 0;
}  // main()
