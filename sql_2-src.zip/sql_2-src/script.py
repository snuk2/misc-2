import hashlib
import string
import random

def main():
    password = "'+'"
    while(True):
        stringy = ''.join(random.choices(string.ascii_letters, k=64))
        password_bytes = ("bungle-" + stringy).encode("latin-1")
        password_digest = hashlib.sha256(password_bytes).digest().decode("latin-1")
        if password in password_digest:
            print(stringy)
            break

if __name__ == "__main__":
    main()    